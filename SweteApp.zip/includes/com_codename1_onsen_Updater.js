(function(exports){

var o = {};

    o.updateWebHarness_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_codename1_onsen_Updater= o;

})(cn1_get_native_interfaces());
