(function(exports){

var o = {};

    o.execute__java_lang_String = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.addJSCallback__java_lang_String_int = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.removeWindowResizeListener__int = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.addWebEventListener__java_lang_String_int = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.addWindowResizeListener__int = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getInternalId_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.initBrowserWindowNative__int = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.removeJSCallback__int = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setDebugMode__boolean = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setSize__int_int = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getX_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getY_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.putClientProperty__java_lang_String_int = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setVisible__boolean = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setPosition__int_int = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getWidth_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getHeight_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.addWindowListener__int = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.removeWindowListener__int = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getTitle_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setTitle__java_lang_String = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setURLHierarchy__java_lang_String = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.setFireCallbacksOnEdt__boolean = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.executeAndReturnString__java_lang_String = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_codename1_htmlform_BrowserWindowNative= o;

})(cn1_get_native_interfaces());
